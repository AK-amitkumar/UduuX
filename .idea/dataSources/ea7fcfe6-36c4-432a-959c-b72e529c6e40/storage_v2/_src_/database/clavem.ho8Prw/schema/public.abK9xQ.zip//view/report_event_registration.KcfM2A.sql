CREATE VIEW report_event_registration AS
  SELECT ((((e.id)::character varying)::text || '/'::text) || (COALESCE((r.id)::character varying, ''::character varying))::text) AS id,
    e.id AS event_id,
    e.user_id,
    r.name AS name_registration,
    r.create_date,
    e.company_id,
    e.date_begin AS event_date,
    count(r.id) AS nbevent,
    count(r.event_id) AS nbregistration,
        CASE
            WHEN ((r.state)::text = 'draft'::text) THEN count(r.event_id)
            ELSE (0)::bigint
        END AS draft_state,
        CASE
            WHEN ((r.state)::text = ANY ((ARRAY['open'::character varying, 'done'::character varying])::text[])) THEN count(r.event_id)
            ELSE (0)::bigint
        END AS confirm_state,
        CASE
            WHEN ((r.state)::text = 'cancel'::text) THEN count(r.event_id)
            ELSE (0)::bigint
        END AS cancel_state,
    e.event_type_id,
    e.seats_max,
    e.state AS event_state,
    r.state AS registration_state
   FROM (event_event e
     LEFT JOIN event_registration r ON ((e.id = r.event_id)))
  GROUP BY r.event_id, r.id, r.state, e.event_type_id, e.id, e.date_begin, e.user_id, e.state, e.company_id, e.seats_max, r.name;

