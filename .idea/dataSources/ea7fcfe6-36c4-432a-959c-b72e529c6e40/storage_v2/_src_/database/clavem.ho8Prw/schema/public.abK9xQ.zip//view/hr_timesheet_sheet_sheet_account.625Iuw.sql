CREATE VIEW hr_timesheet_sheet_sheet_account AS
  SELECT min(l.id) AS id,
    l.account_id AS name,
    s.id AS sheet_id,
    sum(l.unit_amount) AS total
   FROM (account_analytic_line l
     LEFT JOIN hr_timesheet_sheet_sheet s ON (((s.date_to >= l.date) AND (s.date_from <= l.date) AND (s.user_id = l.user_id))))
  GROUP BY l.account_id, s.id;

