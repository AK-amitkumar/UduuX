CREATE VIEW crm_activity_report AS
  SELECT m.id,
    m.subtype_id,
    m.author_id,
    m.date,
    m.subject,
    l.id AS lead_id,
    l.user_id,
    l.team_id,
    l.country_id,
    l.company_id,
    l.stage_id,
    l.partner_id,
    l.type AS lead_type,
    l.active,
    l.probability
   FROM (mail_message m
     JOIN crm_lead l ON ((m.res_id = l.id)))
  WHERE ((m.model)::text = 'crm.lead'::text);

