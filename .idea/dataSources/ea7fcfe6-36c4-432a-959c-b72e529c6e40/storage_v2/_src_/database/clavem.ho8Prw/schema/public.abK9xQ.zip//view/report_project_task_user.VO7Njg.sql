CREATE VIEW report_project_task_user AS
  SELECT ( SELECT 1) AS nbr,
    t.id,
    t.date_start,
    t.date_end,
    t.date_last_stage_update,
    t.date_deadline,
    abs((date_part('epoch'::text, (t.write_date - t.date_start)) / ((3600 * 24))::double precision)) AS no_of_days,
    t.user_id,
    t.project_id,
    t.priority,
    t.name,
    t.company_id,
    t.partner_id,
    t.stage_id,
    t.kanban_state AS state,
    (date_part('epoch'::text, (NULLIF(t.date_end, t.write_date) - t.create_date)) / ((3600 * 24))::double precision) AS closing_days,
    (date_part('epoch'::text, (t.date_start - t.create_date)) / ((3600 * 24))::double precision) AS opening_days,
    (date_part('epoch'::text, ((t.date_deadline)::timestamp without time zone - timezone('UTC'::text, now()))) / ((3600 * 24))::double precision) AS delay_endings_days,
    t.progress,
    t.effective_hours AS hours_effective,
    t.remaining_hours,
    t.total_hours,
    t.delay_hours AS hours_delay,
    t.planned_hours AS hours_planned
   FROM project_task t
  WHERE (t.active = true)
  GROUP BY t.id, t.create_date, t.write_date, t.date_start, t.date_end, t.date_deadline, t.date_last_stage_update, t.user_id, t.project_id, t.priority, t.name, t.company_id, t.partner_id, t.stage_id, t.remaining_hours, t.effective_hours, t.progress, t.total_hours, t.planned_hours, t.delay_hours;

