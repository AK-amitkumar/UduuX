CREATE VIEW business_requirement_deliverable_sale_report AS
  SELECT br.id,
    br.name,
    br.description,
    br.partner_id,
    br.project_id,
    br.change_request,
    br.priority,
    dlv.product_id AS dlv_product,
    dlv.name AS dlv_description,
    res.product_id AS res_product,
    res.name AS res_description,
    count(DISTINCT br.id) AS br_count,
    count(DISTINCT dlv.id) AS dlv_count,
    count(DISTINCT res.id) AS res_count,
    res.qty AS res_qty,
    dlv.qty AS dlv_qty,
    dlv.sale_price_unit AS sale_price,
    (dlv.sale_price_unit * dlv.qty) AS total_revenue
   FROM ((business_requirement br
     FULL JOIN business_requirement_deliverable dlv ON ((br.id = dlv.business_requirement_id)))
     FULL JOIN business_requirement_resource res ON ((res.business_requirement_deliverable_id = dlv.id)))
  GROUP BY dlv.id, br.id, res.id;

