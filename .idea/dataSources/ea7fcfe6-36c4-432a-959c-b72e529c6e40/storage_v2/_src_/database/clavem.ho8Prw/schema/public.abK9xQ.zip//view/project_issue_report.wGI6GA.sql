CREATE VIEW project_issue_report AS
  SELECT c.id,
    c.date_open AS opening_date,
    c.create_date,
    c.date_last_stage_update,
    c.user_id,
    c.working_hours_open,
    c.working_hours_close,
    c.stage_id,
    c.date_closed,
    c.company_id,
    c.priority,
    c.project_id,
    1 AS nbr_issues,
    c.partner_id,
    c.day_open AS delay_open,
    c.day_close AS delay_close,
    ( SELECT count(mail_message.id) AS count
           FROM mail_message
          WHERE (((mail_message.model)::text = 'project.issue'::text) AND ((mail_message.message_type)::text = ANY ((ARRAY['email'::character varying, 'comment'::character varying])::text[])) AND (mail_message.res_id = c.id))) AS email
   FROM (project_issue c
     LEFT JOIN project_task t ON ((c.task_id = t.id)))
  WHERE (c.active = true);

