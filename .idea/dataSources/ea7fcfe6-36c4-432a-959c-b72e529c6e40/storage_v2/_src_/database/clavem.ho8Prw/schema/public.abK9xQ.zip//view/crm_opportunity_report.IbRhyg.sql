CREATE VIEW crm_opportunity_report AS
  SELECT c.id,
    c.date_deadline,
    c.date_open AS opening_date,
    c.date_closed,
    c.date_last_stage_update,
    c.user_id,
    c.probability,
    c.stage_id,
    stage.name AS stage_name,
    c.type,
    c.company_id,
    c.priority,
    c.team_id,
    ( SELECT count(*) AS count
           FROM mail_message m
          WHERE (((m.model)::text = 'crm.lead'::text) AND (m.res_id = c.id))) AS nbr_activities,
    c.active,
    c.campaign_id,
    c.source_id,
    c.medium_id,
    c.partner_id,
    c.city,
    c.country_id,
    c.planned_revenue AS total_revenue,
    (c.planned_revenue * (c.probability / (100)::double precision)) AS expected_revenue,
    c.create_date,
    (date_part('epoch'::text, (c.date_closed - c.create_date)) / ((3600 * 24))::double precision) AS delay_close,
    abs((date_part('epoch'::text, ((c.date_deadline)::timestamp without time zone - c.date_closed)) / ((3600 * 24))::double precision)) AS delay_expected,
    (date_part('epoch'::text, (c.date_open - c.create_date)) / ((3600 * 24))::double precision) AS delay_open,
    c.lost_reason,
    c.date_conversion
   FROM (crm_lead c
     LEFT JOIN crm_stage stage ON ((stage.id = c.stage_id)))
  GROUP BY c.id, stage.name;

