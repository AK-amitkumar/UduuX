CREATE VIEW report_membership AS
  SELECT min(foo.id) AS id,
    foo.partner_id,
    count(foo.membership_id) AS quantity,
    foo.user_id,
    foo.membership_state,
    foo.associate_member_id,
    foo.membership_amount,
    foo.date_to,
    foo.start_date,
    count(foo.num_waiting) AS num_waiting,
    count(foo.num_invoiced) AS num_invoiced,
    count(foo.num_paid) AS num_paid,
    sum(foo.tot_pending) AS tot_pending,
    sum(foo.tot_earned) AS tot_earned,
    foo.membership_id,
    foo.company_id
   FROM ( SELECT min(p.id) AS id,
            p.id AS partner_id,
            p.user_id,
            p.membership_state,
            p.associate_member AS associate_member_id,
            p.membership_amount,
            p.membership_stop AS date_to,
            p.membership_start AS start_date,
                CASE
                    WHEN ((ml.state)::text = 'waiting'::text) THEN ml.id
                    ELSE NULL::integer
                END AS num_waiting,
                CASE
                    WHEN ((ml.state)::text = 'invoiced'::text) THEN ml.id
                    ELSE NULL::integer
                END AS num_invoiced,
                CASE
                    WHEN ((ml.state)::text = 'paid'::text) THEN ml.id
                    ELSE NULL::integer
                END AS num_paid,
                CASE
                    WHEN ((ml.state)::text = ANY ((ARRAY['waiting'::character varying, 'invoiced'::character varying])::text[])) THEN sum(il.price_subtotal)
                    ELSE (0)::numeric
                END AS tot_pending,
                CASE
                    WHEN (((ml.state)::text = 'paid'::text) OR ((p.membership_state)::text = 'old'::text)) THEN sum(il.price_subtotal)
                    ELSE (0)::numeric
                END AS tot_earned,
            ml.membership_id,
            p.company_id
           FROM (((res_partner p
             LEFT JOIN membership_membership_line ml ON ((ml.partner = p.id)))
             LEFT JOIN account_invoice_line il ON ((ml.account_invoice_line = il.id)))
             LEFT JOIN account_invoice ai ON ((il.invoice_id = ai.id)))
          WHERE (((p.membership_state)::text <> 'none'::text) AND (p.active = true))
          GROUP BY p.id, p.user_id, p.membership_state, p.associate_member, p.membership_amount, p.membership_start, ml.membership_id, p.company_id, ml.state, ml.id) foo
  GROUP BY foo.start_date, foo.date_to, foo.partner_id, foo.user_id, foo.membership_id, foo.company_id, foo.membership_state, foo.associate_member_id, foo.membership_amount;

